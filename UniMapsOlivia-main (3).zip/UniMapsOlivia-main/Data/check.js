const data = require('./data_kemiskinan.json')
hasil = Object.defineProperty(data, "kecamatan")
console.log(Object.values(hasil))